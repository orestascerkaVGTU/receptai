<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Ingredient;

class AdminController extends Controller
{
   public function __construct()
    {
        $this->middleware('admin');
    }

    public function recipes()
    {
       $recipes = Recipe::orderBy('updated_at', 'DESC')->get();
       return view('admin.recipes', compact('recipes'));
    }  
    
    public function showToggle(Request $request)
    {
      $recipe = Recipe::find($request->id);
      $recipe->update(['show' => !$recipe->show]);
      
      return response()->json(['success'=>$request->id]);
    }  

    public function unconfirmedrecipes()
    {
       $recipes = Recipe::where('show', 0)->orderBy('updated_at', 'DESC')->get();
       return view('admin.recipes', compact('recipes'));
    }

    public function comments()
    {
       $comments = Comment::orderBy('updated_at', 'DESC')->get();
       return view('admin.comments', compact('comments'));
    }

    public function add()
    {
       $ingredients = Ingredient::orderBy('id','desc')->get();
       return view('admin.add', compact('ingredients'));
    }

    public function store(Request $request)
    {
      $validated = $request->validate([
         'name' => 'required|unique:ingredients,name|max:35',
     ]);

     $ing = Ingredient::create($validated);
       return back()->with('message',"Ingridientas $ing->name pridėtas");
    }

    public function delete(Request $request, Ingredient $ingredient)
    {
      $ingredient->delete();
   //   $ing = Ingredient::create($validated);
       return back()->with('message',"Ingridientas ištrintas");
    }
}

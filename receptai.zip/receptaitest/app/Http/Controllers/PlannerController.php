<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Day;
use App\Models\Recipe;
use Illuminate\Support\Facades\Auth;

class PlannerController extends Controller
{
    public function index()
    {
        $days = Day::where('user_id', Auth::id())->get();
        return view('profiles.planner', compact('days'));
    }

    public function add(Request $request, Recipe $recipe)
    {
        if ($request->day != '') {
            $day = Day::where('user_id', Auth::id())->where('day_number', $request->day)->first();
            $day->recipes()->toggle($recipe->id);
        }
       
        return back();
    }

    public function remove(Request $request, Recipe $recipe)
    {
        if ($request->day != '') {
            $day = Day::where('user_id', Auth::id())->where('day_number', $request->day)->first();
            $day->recipes()->toggle($recipe->id);
        }
       
        return back()->with('message','Receptas ištrintas');
    }

    public function comment(Request $request)
    {
        if ($request->day != '') {
            $day = Day::where('user_id', Auth::id())->where('day_number', $request->day)->first();
            $day->update(['comments' => $request->comment]);
        }
       
        return back()->with('message','Komentaras išsaugotas');
    }

    public function destroy(Request $request)
    {
        if ($request->day != '') {
            $day = Day::where('user_id', Auth::id())->where('day_number', $request->day)->first();
            $day->update(['comments' => '']);
            $day->recipes()->detach();
        }
        return back()->with('message','Receptai ir komentarai ištrinti');
    }
}

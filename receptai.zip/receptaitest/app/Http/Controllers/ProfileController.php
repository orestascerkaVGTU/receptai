<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Recipe;

class ProfileController extends Controller
{
    public function index()
    {
        return view('profiles.index');
    }

    public function favorites()
    {
        $recipes = Recipe::whereLikedBy(Auth::id()) // find only articles where user liked them
        ->with('likeCounter') // highly suggested to allow eager load
        ->get();
        return view('profiles.favorites', compact('recipes'));
    }

    public function forget(Request $request)
    {
        $recipe = Recipe::find($request->id);
        $recipe->unlike();
        
        return response()->json(['success'=>$request->id]);
    }

    public function recipes()
    {
        $recipes = Recipe::where('user_id', Auth::id())->get();
        return view('profiles.myrecipes', compact('recipes'));
    }
}

<?php

namespace App\Http\Livewire;

use App\Models\Ingredient;
use Livewire\Component;
 use App\Models\Recipe;
 use Illuminate\Support\Facades\Auth;
 use Livewire\WithPagination;

class Counter extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    
    public $search;
    public $selectedIngredients = [];
    public $filterSelectedIngredients;


    public function updatingSearch()
    {
        $this->resetPage();
    }



    public function render()
    {
        $recipesQuery = Recipe::where('show', true)->where('name', 'like', '%'.$this->search.'%')->withCount('ingredients');
        $ids_ordered = implode(',', $this->selectedIngredients);
        
        if($this->selectedIngredients){
            $selectedActivities = $this->selectedIngredients;
            $recipesQuery->whereHas('ingredients', function($query) use($selectedActivities) {
                $query->whereIn('id', $selectedActivities);
            })->orderBy('created_at','desc');
            $recipes = $recipesQuery->get();
        } else {
            $recipes = $recipesQuery->paginate(9);
        }
        

        
        $ingredients = Ingredient::where('name', 'like', '%'.$this->filterSelectedIngredients.'%')->get();
        
        return view('livewire.counter', compact('recipes','ingredients'));
    }

    public function toggleLike($id)
    {
        if (Auth::check()) {
            $car = Recipe::find($id);
            if ($car->liked()) {
                $car->unlike();
            } else {
                $car->like();
            }

        } else {
            session()->flash('message', 'Prisijunkite norėdami išsaugoti');
        }
    }
}















// $records = \App\Models\Car::whereHas('payments', function ($payment){
//     $payment->valid();
// })->select(
//     'cars.id',
//     'cars.month',
//     'cars.year',
//     'cars.price',
//     'cars.old_price',
//     'cars.engine',
//     'cars.gears',
//     'cars.created_at',
//     'cars.slug',
//     'cars.city_id',
//     'cities.id as cityID',
//     'cities.title as city_name',
//     'fuels.id as fuelID',
//     'fuels.title as fuel_name',
//     'bodies.id as bodyID',
//     'bodies.title as body_name',
//     'cars_make.id as brandID',
//     'cars_make.title as brand',
//     'cars_models.id as modelID',
//     'cars_models.title as model',
//     'stars.star as star',
//     'stars.price as starPrice'
// )
// ->join('cities','cities.id', '=', 'cars.city_id')
// ->join('fuels', 'cars.fuel_id', '=', 'fuels.id')
// ->join('bodies', 'cars.body_id', '=', 'bodies.id')
// ->join('cars_make', 'cars.car_make_id', '=', 'cars_make.id')
// ->join('cars_models', 'cars.car_model_id', '=', 'cars_models.id')
// ->join('payments', 'cars.id', '=', 'payments.car_id')
// ->join('stars', 'payments.star_id', '=', 'stars.star')
// ->with(['images'])->orderBy('star', 'desc');

// if ($this->brand) {
//     $records->whereIn('cars_make.id', $this->brand);
// }

// if ($this->model) {
//     $records->whereIn('cars_models.id', $this->model);
// }



// if ($this->min_year != 1950 || $this->max_year != 2021) {
//     $records->whereBetween('cars.year', [$this->min_year, $this->max_year]);
// }
// if ($this->min_price != 150 || $this->max_price != 300000) {
//     $records->whereBetween('cars.price', [$this->min_price, $this->max_price]);
// }
// if ($this->gears != ['Mechaninė', 'Automatinė']) {
//     $records->whereIn('cars.gears', $this->gears);
// }
// if ($this->fuels != ['1', '2', '3', '4', '5', '6', '7', '8', '9']) {
//     $records->whereIn('cars.fuel_id', $this->fuels);
// }
// if ($this->bodies != ['1', '2', '3', '4', '5', '6', '7', '8', '9']) {
//     $records->whereIn('cars.body_id', $this->bodies);
// }


// if ($this->sortby != '') {
//     $records->orderBy('price', $this->sortby);
// } else {
//     $records->orderBy('created_at', 'desc');
// }


// $filteredRecords = $records->paginate($this->showResults);
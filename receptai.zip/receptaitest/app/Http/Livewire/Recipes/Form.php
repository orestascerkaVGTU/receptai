<?php

namespace App\Http\Livewire\Recipes;

use Livewire\Component;
use App\Models\Ingredient;

class Form extends Component
{
    public $filterSearch;
    public $selectedIngredients = [];

    public function render() 
    {
        $ingredients = Ingredient::where('name', 'like', '%'.$this->filterSearch.'%')->get();
        return view('livewire.recipes.form', compact('ingredients'));
    }
}

<?php

namespace App\Http\Livewire\Recipes;

use Livewire\Component;
use App\Models\Ingredient;

class FormEdit extends Component
{

    public $recipe;
    public $filterSearch;
    public $selectedIngredients = [];

    public function mount()
    {
        $existingIngredients = $this->recipe->ingredients->pluck('id')->toArray();
        $this->selectedIngredients = $existingIngredients;
    }

    public function render()
    {
        
        $ingredients = Ingredient::where('name', 'like', '%'.$this->filterSearch.'%')->get();
        return view('livewire.recipes.form-edit', compact('ingredients'));
    }
}

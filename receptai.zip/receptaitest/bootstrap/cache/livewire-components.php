<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'recipes.form' => 'App\\Http\\Livewire\\Recipes\\Form',
  'recipes.form-edit' => 'App\\Http\\Livewire\\Recipes\\FormEdit',
  'toggle-recipe' => 'App\\Http\\Livewire\\ToggleRecipe',
);
<?php

namespace Database\Seeders;


use App\Models\Ingredient;
use App\Models\Recipe;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'admin',
            'email' => 'admin@email.com',
            'password' => bcrypt('password'),
            'admin' => true
        ]);

        

        $this->call([
            IngredientSeeder::class,
            DaySeeder::class,
            // RecipeSeeder::class
        ]);

        // Creating recipes from factory
        \App\Models\Recipe::factory(50)->create();
        $ingredients = Ingredient::all();
        Recipe::all()->each(function ($recipe) use ($ingredients) { 
            $recipe->ingredients()->attach(
                $ingredients->random(rand(1, 2))->pluck('id')->toArray()
            ); 
        });

    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Day;
use Illuminate\Support\Facades\DB;

class DaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = User::all();
        
        $items = [
            "Pirmadienis",
            "Antradienis",
            "Trečiadienis",
            "Ketvirtadienis",
            "Penktadienis",
            "Šeštadienis",
            "Sekmadienis",
        ];
        foreach ($users as $user) {
            foreach($items as $key => $item){
                DB::table('days')->insert([
                    'day' => $item,
                    'day_number' => ++$key,
                    'user_id' => $user->id
                ]);
            }
        }
    }
}

<?php

namespace Database\Seeders;

use App\Models\Recipe;
use Illuminate\Database\Seeder;

class RecipeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $recipes = [
            [
                'name' => 'Pica',
                'description' => 'Nice pica',
                'instructions' => 'Lorem ipsum',
                'time' => rand(5,150),
                'ingredients' => [1,2,3]
            ],
            [
                'name' => 'Burger',
                'description' => 'Nice burger',
                'instructions' => 'Lorem ipsum',
                'time' => rand(5,150),
                'ingredients' => [1,4,3]
            ],
            [
                'name' => 'Pasta',
                'description' => 'Nice pasta',
                'instructions' => 'Lorem ipsum',
                'time' => rand(5,150),
                'ingredients' => [1,4,5]
            ]
        ];




        foreach($recipes as $recipe){
           $r = new Recipe();
           $r->name = $recipe['name'];
           $r->description = $recipe['description'];
           $r->instructions = $recipe['instructions'];
           $r->time = $recipe['time'];
           $r->show = true;
           $r->save();

            $r->ingredients()->sync($recipe['ingredients']);
        }
    }
}


// 'name' => $this->faker->foodName(),
// 'short_description' => $this->faker->realText($maxNbChars = 100, $indexSize = 2),
// 'description' => $this->faker->realText($maxNbChars = 800, $indexSize = 2),
// 'cook_time' => $this->faker->numberBetween($min = 5, $max = 10),
// 'time' => $this->faker->numberBetween($min = 10, $max = 90),
// 'instructions' => $this->faker->realText($maxNbChars = 200, $indexSize = 2),
// 'show' => true
<div class="accordion" id="accordionExample">
    <div class="card">
      <div class="card-header" id="headingOne">
        <h2 class="mb-0">
          <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Produktai (pasirinkti): <span class="text-danger">*</span>
          </button>
        </h2>
        <input wire:model="filterSearch" class="form-control form-control-sm" type="search" placeholder="Įvesti fragmentą ..">
      </div>
  
      <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
        <div class="card-body row ml-3">
            {{-- @php
                $existingIngredients = $recipe->ingredients->pluck('id')->toArray();
            @endphp --}}
            @foreach ($ingredients as $item)
            <div class="form-check col-6 col-md-3 col-lg-2">
                <input class="form-check-input {{ $selectedIngredients ? '' : 'is-invalid' }}" type="checkbox" name="ingredients[]" wire:model="selectedIngredients" value="{{ $item->id }}" id="ingredients{{ $item->id }}" >
                <label class="form-check-label" for="ingredients">
                  {{ $item->name }}
                </label>
              </div>
            @endforeach
            {{-- <div class="form-check col-6 col-md-3 col-lg-2">
                <input class="form-check-input" type="checkbox" name="dairies[]" value="{{ $item->id }}" id="dairies">
                <label class="form-check-label" for="dairies">
                  {{ $item->name }}
                </label>
              </div> --}}
        </div>
      </div>
    </div>

  </div>

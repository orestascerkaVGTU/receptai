<div class="accordion" id="accordionExample">
    <div class="card">
      <div class="card-header" id="headingOne">
        <h2 class="mb-0">
          <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Produktai (pasirinkti): <span class="text-danger">*</span>
          </button>
          
        </h2>
        <input wire:model="filterSearch" class="form-control form-control-sm" type="search" placeholder="Įvesti fragmentą ..">
      </div>
      
      <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
        <div class="card-body row ml-3">
            @foreach ($ingredients as $item)
            <div class="form-check col-6 col-md-3 col-lg-2">
                <input class="form-check-input  {{ $selectedIngredients ? '' : 'is-invalid' }}" type="checkbox" name="ingredients[]" wire:model="selectedIngredients" value="{{ $item->id }}" id="ingredient{{ $item->id }}">
                <label class="form-check-label" for="ingredients">
                  {{ $item->name }}
                </label>
              </div>
            @endforeach
            
           
        </div>
      </div>
    </div>
    {{-- <div class="card">
      <div class="card-header" id="headingTwo">
        <h2 class="mb-0">
          <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Daržovės (pasirinkti):
          </button>
        </h2>
      </div>
      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
        <div class="card-body row ml-3">
            @foreach ($vegetables as $item)
            <div class="form-check col-6 col-md-3 col-lg-2">
                <input class="form-check-input" type="checkbox" name="vegetables[]" value="{{ $item->id }}" id="vegetables">
                <label class="form-check-label" for="vegetables">
                  {{ $item->name }}
                </label>
              </div>
            @endforeach
        </div>
      </div>
    </div> --}}
    {{-- <div class="card">
      <div class="card-header" id="headingThree">
        <h2 class="mb-0">
          <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            Collapsible Group Item #3
          </button>
        </h2>
      </div>
      <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
        <div class="card-body">
          And lastly, the placeholder content for the third and final accordion panel. This panel is hidden by default.
        </div>
      </div>
    </div> --}}
  </div>

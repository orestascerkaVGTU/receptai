@extends('adminlte::page')

@section('title', 'Mėgstamiausi')

@section('content_header')
    <h1>Mėgstamiausi ({{ $recipes->count() }})</h1>
@stop

@section('content')
    <p>Jūsų pamėgti receptai</p>
    <div class="container">
        <div class="row">
            @foreach ($recipes as $item)
                <div class="col-md-6 col-lg-4" >
                    <div class="card relative" >
                         <div style="position: absolute;right:0px;">
                                <button style="background: transparent" class="removeFav border-0" value="{{ $item->id }}">
                                  <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ff0000" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                  </svg>
                                  
                              </button>
                              </div>
                        <img style="height: 250px;" src="{{ $item->image ? \Storage::url($item->image) : 'https://www.staticwhich.co.uk/static/images/products/no-image/no-image-available.png' }}" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h4 class="card-text"><a href="{{ route('recipes.show', $item) }}">{{ $item->name }}</a></h4>
                        </div>
                      </div>
                </div>
            @endforeach
        </div>
    </div>
@stop



@section('js')
<script>

    $(".removeFav").click(function(event){
        event.preventDefault();
  
        let id = $(this).attr('value');
        let _token   = $('meta[name="csrf-token"]').attr('content');
        var that = this;
  
        $.ajax({
          url: "/profiles/favorites/forget",
          type:"POST",
          data:{
            id:id,
            _token: _token
          },
          success:function(response){
            if(response) {
                $(that).closest('.col-md-6').remove(); 
            }
          },
         });
    });
  </script>
@stop

@extends('adminlte::page')

@section('title', 'Favorites')

@section('content_header')
    {{-- <h1>Mėgstamiausi ({{ $recipes->count() }})</h1> --}}
@stop

@section('css')
{{-- <link rel="stylesheet" href="{{ asset('css/star-rating.min.css') }}">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
<link rel="stylesheet" href="{{ asset('css/theme.min.css') }}"> --}}
<link rel="stylesheet" href="{{ asset('css/jquery.raty.css') }}">
@stop

@section('content')
<style>
    :disabled {
    color: green;
    font-weight: 600
    }
</style>

<div class="container py-3">
    @if(Session::has('message'))
    <div class="alert alert-dismissible fade show {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    @endif
    @if ($errors->any())
    <div class="alert alert-danger">
        Ištaisykite žemiau esančias klaidas
    </div>
@endif
    <div class="row">
        <div class="col-lg-8 relative">
            <div style="position: absolute;right:5px;">
                <form action="{{ route('like',$recipe) }}" method="post">
                    @csrf
                <button class="border-0" type="submit">
                  @if ($recipe->liked())
                    <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ff0000" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  @else 
                    <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ffffff" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  @endif
                  
                </button>
                </form>
              </div>
            <h2>{{ $recipe->name }}</h2>
            <img src="{{$recipe->image ? \Storage::url($recipe->image)  : 'https://www.staticwhich.co.uk/static/images/products/no-image/no-image-available.png'}}" class="card-img-top img-fluid" alt="...">
            @if ($recipe->short_description)
                <div class="jumbotron">
                    <p class="lead">
                        {{ $recipe->short_description }}
                    </p>
                </div>
            @endif
            

            @if ($recipe->description)
                <div class="p-3">
                    <h5>Aprašymas</h5>
                    <hr class="mr-auto" style="width: 200px;">
                    <p class="leading-5 ">{!! $recipe->description !!}</p>
                </div>
            @endif

            @if ($recipe->instructions)
                <div class="p-3">
                    <h5>Instrukcijos:</h5>
                    <hr class="mr-auto" style="width: 200px;">
                    <p class="leading-5 ">{!! $recipe->instructions !!}</p>
                </div>
            @endif
           

            <div class="p-3 border">
                <h5>Komentarai:</h5>
                <hr>
               {{-- @if (Auth::check()) --}}
               <form action="{{ route('recipe.comment.add', $recipe) }}" method="POST">
                @csrf
                    <div class="float-right {{ $errors->has('rating') ? 'is-invalid' : '' }}" id="hint"></div>
                   
                    <input id="rating" name="rating"  class="rating" hidden>
                    <div id="descriptionFeedback" class="invalid-feedback">
                        {{ $errors->first('rating') }}
                      </div>
                    <div class="form-group">
                        <label for="commentForm">Rašyti komentarą:</label>
                        <textarea class="form-control {{ $errors->has('comment') ? 'is-invalid' : '' }}" name="comment" id="commentForm" rows="3" placeholder="{{ Auth::check() ? '' : 'Norėdami rašyti turite prisijungti ..' }}"></textarea>
                        <div id="descriptionFeedback" class="invalid-feedback">
                            {{ $errors->first('comment') }}
                          </div>
                    </div>
                    <button id="save" class="btn btn-success text-right" >{{ Auth::check() ? 'Siųsti' : 'Prisijungti' }}</button>
                </form>
               {{-- @else
                   
               @endif
                <a href="{{ route('login') }}" class="btn btn-success">Komentuoti</a> --}}
                @foreach ($recipe->comments as $comment)
                    <div class="my-2 p-2 bg-light">
                        
                    </div>
                    <div class="card">
                        <div class="card-header text-white bg-dark">
                            {{ $comment->user ? $comment->user->name : 'Naudotojas' }} 
                            (
                            @for ($i = 0; $i < $comment->rating; $i++)
                            <i class="fas fa-star text-warning"></i>
                            @endfor
                            )
                            <span class="float-right">{{ $comment->created_at->diffForHumans() }}</span>
                        </div>
                        <div class="card-body">
                          <p class="card-text">{{ $comment->comment }}</p>
                        </div>
                      </div>
                @endforeach
            </div>


        </div>
        <div class="col-lg-4  p-2 shadow-sm">
            @auth
            <form action="{{ route('planner.add', $recipe) }}" method="post">
                @csrf
                    <div class="input-group">
                        <select class="custom-select" name="day" id="inputGroupSelect04" aria-label="Example select with button addon" required>
                        <option selected value="">Rinktis dieną...</option>
                        @foreach ($days as $item)
                            <option value="{{ $item->day_number }}" {{ $item->recipes()->where('recipe_id', $recipe->id)->exists() ? 'disabled' :'' }}>{{ $item->day }}</option>
                        @endforeach
                        </select>
                        <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="submit">Pridėti į planuoklį</button>
                        </div>
                    </div>
                </form>
            @endauth
            @guest
            <div class="input-group">
                <select class="custom-select" name="day" id="inputGroupSelect04" aria-label="Example select with button addon" required>
                <option selected disabled value="">Turite prisijungti...</option>
                
                </select>
                <div class="input-group-append">
                <a href="{{ route('login') }}" class="btn btn-outline-secondary" type="submit">Pridėti į planuoklį</a>
                </div>
            </div>
            @endguest

            <h3 class="mt-3 ">Ingridientai: 
                @can('update', $recipe)
                <a href="{{ route('recipes.edit', $recipe) }}" class="float-right text-sm btn btn-sm btn-warning">Redaguoti</a>
                @endcan
            </h3>
                <hr class="mx-4">
                    @if (count($recipe->ingredients) > 0)
                        <div class="p-3">
                            <h5 class="lead">Produktai:</h5>
                            <ul>
                                @foreach ($recipe->ingredients as $item)
                                <li>{{ $item->name }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    @if ($recipe->time)
                        <p class="mt-3 px-3">Paruošimo laikas: <span class="text-bold">{{ $recipe->time }}</span> min.</p>
                    @endif

                    @if ($recipe->cook_time)
                        <p class="mt-3 px-3">Kepimo(virimo) laikas: <span class="text-bold">{{ $recipe->cook_time }}</span> min.</p>
                    @endif

                    @if ($recipe->calories)
                        <p class="mt-3 px-3">Viso kalorijų: <span class="text-bold">{{ $recipe->calories }}</span> kcal.</p>
                    @endif
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <script src="{{ asset('js/jquery.raty.js') }}"></script>
    <script>
        $('#hint').raty({
            'path': '/images/',
            'target':       '#rating',
            'targetType':   'score',
            'targetKeep':   true
        });
    </script>


@stop




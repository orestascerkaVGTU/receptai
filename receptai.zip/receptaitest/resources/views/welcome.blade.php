@extends('adminlte::page')

@section('title', 'Pradžia')

@section('content_header')

@stop

@section('content')
<livewire:counter />
<div style="position: absolute;
bottom:5px;right:10px;">
    <a class="btn btn-dark" href="#">Į viršų</a>
</div>
@stop

@section('css')
{{-- <style>
    html,
    body {
        height: 80vh;
    }
</style> --}}
@endsection

@section('js')
{{-- <script type="text/javascript">
    window.onscroll = function (ev) {
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
            window.livewire.emit('load-more');
        }
    };

</script> --}}
@stop
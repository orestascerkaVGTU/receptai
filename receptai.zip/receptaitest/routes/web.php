<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PlannerController;
use App\Http\Controllers\CommentController;
use App\Models\Recipe;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [RecipeController::class, 'index'])->name('index');

Route::post('/like/{recipe}', function (Recipe $recipe) {
    if (Auth::check()) {
        $recipe->liked() ? $recipe->unlike() : $recipe->like();
        return back()->with('message', 'Išsaugota');
    } else {
        return back()->with('message', 'Prisijunkite norėdami išsaugoti');
    }

})->name('like');

Route::prefix('profiles')->name('profiles.')->middleware('auth')->group(function () {
    Route::get('', [ProfileController::class, 'index'])->name('index');
    Route::get('/favorites', [ProfileController::class, 'favorites'])->name('favorites');
    Route::post('/favorites/forget', [ProfileController::class, 'forget'])->name('forget');
    Route::get('/recipes', [ProfileController::class, 'recipes'])->name('profiles.recipes');
});

Route::prefix('planner')->name('planner.')->middleware('auth')->group(function () {
    Route::get('', [PlannerController::class, 'index'])->name('all');
    Route::post('/add/{recipe}', [PlannerController::class, 'add'])->name('add');
    Route::post('/remove/{recipe}', [PlannerController::class, 'remove'])->name('remove');
    Route::delete('/destroy', [PlannerController::class, 'destroy'])->name('destroy');
    Route::post('/comment', [PlannerController::class, 'comment'])->name('add.comment');
});

Route::post('/{recipe}/comments', [CommentController::class, 'store'])->name('recipe.comment.add')->middleware('auth');





Route::resource('recipes', RecipeController::class);
Route::get('admin/recipes', [AdminController::class, 'recipes'])->name('admin.recipes');
Route::get('admin/recipes/unconfirmed', [AdminController::class, 'unconfirmedrecipes'])->name('admin.recipes.unconfirmed');
Route::post('admin/recipes/unconfirmed', [AdminController::class, 'showToggle'])->name('show.toggle');
Route::get('admin/add/ingredient', [AdminController::class, 'add'])->name('ingredients');
Route::post('admin/add/ingredient', [AdminController::class, 'store'])->name('add.ingredient');
Route::get('admin/comments', [AdminController::class, 'comments'])->name('admin.comments');
Route::delete('comment/destroy/{comment}', [CommentController::class, 'destroy'])->name('comment.destroy');
Route::delete('admin/remove/ingredient/{ingredient}', [AdminController::class, 'delete'])->name('ingredient.destroy');

// Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Auth::routes();

// Route::get('password/reset', 'ResetPasswordController@showResetForm')->name('password.reset');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

// Route::get('/home', function() {
//     return view('home');
// })->name('home')->middleware('auth');

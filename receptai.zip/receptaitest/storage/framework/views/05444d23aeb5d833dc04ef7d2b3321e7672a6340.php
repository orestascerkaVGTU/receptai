

<?php $__env->startSection('title', 'Pradžia'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('counter', [])->html();
} elseif ($_instance->childHasBeenRendered('jG29w8U')) {
    $componentId = $_instance->getRenderedChildComponentId('jG29w8U');
    $componentTag = $_instance->getRenderedChildComponentTagName('jG29w8U');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jG29w8U');
} else {
    $response = \Livewire\Livewire::mount('counter', []);
    $html = $response->html();
    $_instance->logRenderedChild('jG29w8U', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div style="position: absolute;
bottom:5px;right:10px;">
    <a class="btn btn-dark" href="#">Į viršų</a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\receptaitest\resources\views/welcome.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Visi receptai'); ?>

<?php $__env->startSection('content_header'); ?>
<?php if(Route::currentRouteName() == 'admin.recipes.unconfirmed'): ?>
<h1>Nepatvirtinti receptai</h1>
<?php else: ?>
<h1>Visi receptai</h1>
<?php endif; ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
    <div class="alert alert-dismissible fade show <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <?php endif; ?>

    <table class="table table-striped" id="myTable">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Pavadinimas</th>
            <th scope="col">Patvirtintas</th>
            <th scope="col">Įkeltas</th>
            <th scope="col">Autorius</th>
            <th scope="col">Pamėgo</th>
            <th scope="col">Redaguoti</th>
            <th scope="col">Trinti</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($item->id); ?></th>
                <td><a href="<?php echo e(route('recipes.show', $item)); ?>"><?php echo e($item->name); ?></a></td>
                <td>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('toggle-recipe', ['recipe' => $item])->html();
} elseif ($_instance->childHasBeenRendered($item->id)) {
    $componentId = $_instance->getRenderedChildComponentId($item->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->id);
} else {
    $response = \Livewire\Livewire::mount('toggle-recipe', ['recipe' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild($item->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                </td>
                <td><?php echo e($item->created_at->diffForHumans()); ?></td>
                <td><?php echo e($item->user->email); ?></td>
                <td><?php echo e($item->likeCount); ?></td>
                <td><a class="btn btn-warning btn-sm" href="<?php echo e(route('recipes.edit', $item)); ?>">Redaguoti</a></td>
                <td>
                    <form action="<?php echo e(route('recipes.destroy', $item)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Trinti</button>
                    </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          
        </tbody>
      </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>



    <script> 
    $('#myTable').DataTable( {
        responsive: true,
        "order": [[ 3, "asc" ]],
        language: {
            "emptyTable": "Lentelėje nėra duomenų",
            "info": "Rodomi įrašai nuo _START_ iki _END_ iš _TOTAL_ įrašų",
            "infoEmpty": "Rodomi įrašai nuo 0 iki 0 iš 0",
            "infoFiltered": "(atrinkta iš _MAX_ įrašų)",
            "infoThousands": " ",
            "lengthMenu": "Rodyti _MENU_ įrašus",
            "loadingRecords": "Įkeliama...",
            "processing": "Apdorojama...",
            "search": "Ieškoti:",
            "thousands": " ",
            "zeroRecords": "Įrašų nerasta",
            "paginate": {
                "first": "Pirmas",
                "previous": "Ankstesnis",
                "next": "Tolimesnis",
                "last": "Paskutinis"
            },
            "searchPlaceholder": "Ieškoti"
        }
    } );
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\receptaitest\resources\views/admin/recipes.blade.php ENDPATH**/ ?>
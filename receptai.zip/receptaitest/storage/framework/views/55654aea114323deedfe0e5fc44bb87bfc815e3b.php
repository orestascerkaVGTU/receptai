

<?php $__env->startSection('title', 'Sukurti ingridientą'); ?>

<?php $__env->startSection('content_header'); ?>
<h2>Sukurti naują ingridientą:</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="container py-3">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('message')): ?>
    <div class="alert alert-dismissible fade show <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <?php endif; ?>

  <form action="<?php echo e(route('add.ingredient')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="name">Pavadinimas</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="...">
      </div>
      
        <button type="submit" class="btn btn-success">Siųsti</button>
    </form>

    <div class="py-3 row">
        <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 col-lg-3 my-1">
                <form action="<?php echo e(route('ingredient.destroy', $item)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-sm btn-danger mr-2">X</button>
                <?php echo e($item->name); ?> 
                
                </form>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\receptaitest\resources\views/admin/add.blade.php ENDPATH**/ ?>

<div class="container-fluid py-4">

            
    <div class="row">
        <div class="col-md-3 border">
            
            <div class="form-group p-3">
                <input wire:model="search" class="form-control" type="search" placeholder="Ieškoti pagal pavadinimą...">
              </div>

            <h3 class="text-semibold">Turimi produktai</h3>
            <input wire:model="filterSelectedIngredients" class="form-control form-control-sm" type="search" placeholder="Įvesti fragmentą ..">
            <?php if(count($ingredients) < 1): ?>
                <p class="text-muted">Nieko nerasta ..</p>
            <?php endif; ?>
            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" wire:model="selectedIngredients" value="<?php echo e($ingredient->id); ?>" id="ingredient<?php echo e($ingredient->id); ?>">
                <label class="form-check-label" for="ingredient<?php echo e($ingredient->id); ?>">
                  <?php echo e($ingredient->name); ?>

                </label>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          
        </div>
        <div class="col-md-9 relative">
          <?php if(session()->has('message')): ?>
            <div class="alert alert-info">
                <?php echo e(session('message')); ?>

            </div>
          <?php endif; ?>
          <div style="position: absolute;z-index:5;
          top: 99%;
          left: 50%;
          transform: translate(-50%, -50%);z-index:1;color:gray;" wire:loading>
          <div  class="mx-auto" >
            <div class="spinner-border" role="status" style="width: 6rem;height:6rem;">
              <span class="sr-only">Loading...</span>
            </div>
          </div>
        </div>
                
                  <?php if($selectedIngredients): ?>
                  <div class="row">
                    <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                              $requiredIngredients = $recipe->ingredients_count;
                              $result = 0;
                              foreach($recipe->ingredients as $item){
                                if (in_array($item->id, $selectedIngredients)) {
                                  ++$result;
                                }
                              }
                          ?>

                    <?php if($requiredIngredients === $result): ?>
                   
                        <div class="col-12 col-md-6 col-lg-4 mb-3">
                            <div class="card relative">
                              
                              <div class="bg-success" style="position: absolute;left:0px;">
                                <svg style="width:24px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                </svg>
                              </div>
                             
                             
                              <div style="position: absolute;right:0px;">
                                <p class="border-0" type="button" wire:click="toggleLike(<?php echo e($recipe->id); ?>)"
                                  class="absolute cursor-pointer fill-current z-30 top-1  md:top-2 right-2 text-xs md:text-lg font-bold text-black text-opacity-25 md:tracking-widest">
                                  <?php if($recipe->liked()): ?>
                                    <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ff0000" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                    </svg>
                                  <?php else: ?> 
                                    <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ffffff" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                    </svg>
                                  <?php endif; ?>
                                  
                              </p>
                              </div>
                              <img class="img-thumbnail" style="height: 250px;" src="<?php echo e($recipe->image ? \Storage::url($recipe->image)  : 'https://www.staticwhich.co.uk/static/images/products/no-image/no-image-available.png'); ?>" class="card-img-top img-fluid" alt="...">
                                
                              <h5 class="card-title bg-dark pl-3 py-2"><a href="<?php echo e(route('recipes.show', $recipe)); ?>" target="_blank"><?php echo e($recipe->name); ?></a>
                                <span class="float-right mr-3">
                                  <?php for($i = 0; $i < round($recipe->comments->avg('rating')); $i++): ?>
                                <i class="fas fa-star text-warning"></i>
                                <?php endfor; ?>
                                </span>
                              </h5>
                                <div class="card-body" style="height: 120px;">
                                  
                                 
                                  <div>
                                    Ingridientai(<?php echo e($result); ?>/ <?php echo e($requiredIngredients); ?>): 
                                    <?php $__currentLoopData = $recipe->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <span class="<?php echo e(in_array($item->id, $selectedIngredients) ? 'bg-success' : 'bg-danger'); ?> text-white px-1 ml-2"><?php echo e($item->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                   
                                  </div>

                                </div>
                              </div>
                            
                        </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <?php else: ?>   
                  <div class="row">
                      <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-12 col-md-6 col-lg-4 mb-3">
                        <div class="card relative">
                          <div style="position: absolute;right:0px;">
                            <p class="border-0" type="button" wire:click="toggleLike(<?php echo e($recipe->id); ?>)"
                              class="absolute cursor-pointer fill-current z-30 top-1  md:top-2 right-2 text-xs md:text-lg font-bold text-black text-opacity-25 md:tracking-widest">
                              <?php if($recipe->liked()): ?>
                                <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ff0000" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                </svg>
                              <?php else: ?> 
                                <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ffffff" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                </svg>
                              <?php endif; ?>
                              
                          </p>
                          </div>
                          <img class="img-thumbnail" style="height: 250px;" src="<?php echo e($recipe->image ? \Storage::url($recipe->image)  : 'https://www.staticwhich.co.uk/static/images/products/no-image/no-image-available.png'); ?>" class="card-img-top img-fluid" alt="...">
                            
                          <h5 class="card-title bg-dark pl-3 py-2"><a href="<?php echo e(route('recipes.show', $recipe)); ?>" target="_blank"><?php echo e($recipe->name); ?></a>
                            <span class="float-right mr-3">
                              <?php for($i = 0; $i < round($recipe->comments->avg('rating')); $i++): ?>
                            <i class="fas fa-star text-warning"></i>
                            <?php endfor; ?>
                            </span>
                          </h5>
                            <div class="card-body" style="height: 120px;">
                              <div>
                                Ingridientai: 
                                <?php $__currentLoopData = $recipe->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <span class="<?php echo e(in_array($item->id, $selectedIngredients) ? 'bg-success' : 'bg-danger'); ?> text-white px-1 ml-2"><?php echo e($item->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               
                              </div>

                            </div>
                          </div>
                        
                    </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </div>
                    <?php echo e($recipes->links()); ?>

                  <?php endif; ?>
                
                
        </div>
      </div>
      
</div>

<?php /**PATH C:\laragon\www\receptaitest\resources\views/livewire/counter.blade.php ENDPATH**/ ?>
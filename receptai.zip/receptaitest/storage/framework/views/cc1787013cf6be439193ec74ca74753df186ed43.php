


<?php $__env->startSection('title', 'Favorites'); ?>

<?php $__env->startSection('content_header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/jquery.raty.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    :disabled {
    color: green;
    font-weight: 600
    }
</style>

<div class="container py-3">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-dismissible fade show <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        Ištaisykite žemiau esančias klaidas
    </div>
<?php endif; ?>
    <div class="row">
        <div class="col-lg-8 relative">
            <div style="position: absolute;right:5px;">
                <form action="<?php echo e(route('like',$recipe)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <button class="border-0" type="submit">
                  <?php if($recipe->liked()): ?>
                    <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ff0000" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  <?php else: ?> 
                    <svg style="width: 28px;" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="#ffffff" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  <?php endif; ?>
                  
                </button>
                </form>
              </div>
            <h2><?php echo e($recipe->name); ?></h2>
            <img src="<?php echo e($recipe->image ? \Storage::url($recipe->image)  : 'https://www.staticwhich.co.uk/static/images/products/no-image/no-image-available.png'); ?>" class="card-img-top img-fluid" alt="...">
            <?php if($recipe->short_description): ?>
                <div class="jumbotron">
                    <p class="lead">
                        <?php echo e($recipe->short_description); ?>

                    </p>
                </div>
            <?php endif; ?>
            

            <?php if($recipe->description): ?>
                <div class="p-3">
                    <h5>Aprašymas</h5>
                    <hr class="mr-auto" style="width: 200px;">
                    <p class="leading-5 "><?php echo $recipe->description; ?></p>
                </div>
            <?php endif; ?>

            <?php if($recipe->instructions): ?>
                <div class="p-3">
                    <h5>Instrukcijos:</h5>
                    <hr class="mr-auto" style="width: 200px;">
                    <p class="leading-5 "><?php echo $recipe->instructions; ?></p>
                </div>
            <?php endif; ?>
           

            <div class="p-3 border">
                <h5>Komentarai:</h5>
                <hr>
               
               <form action="<?php echo e(route('recipe.comment.add', $recipe)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="float-right <?php echo e($errors->has('rating') ? 'is-invalid' : ''); ?>" id="hint"></div>
                   
                    <input id="rating" name="rating"  class="rating" hidden>
                    <div id="descriptionFeedback" class="invalid-feedback">
                        <?php echo e($errors->first('rating')); ?>

                      </div>
                    <div class="form-group">
                        <label for="commentForm">Rašyti komentarą:</label>
                        <textarea class="form-control <?php echo e($errors->has('comment') ? 'is-invalid' : ''); ?>" name="comment" id="commentForm" rows="3" placeholder="<?php echo e(Auth::check() ? '' : 'Norėdami rašyti turite prisijungti ..'); ?>"></textarea>
                        <div id="descriptionFeedback" class="invalid-feedback">
                            <?php echo e($errors->first('comment')); ?>

                          </div>
                    </div>
                    <button id="save" class="btn btn-success text-right" ><?php echo e(Auth::check() ? 'Siųsti' : 'Prisijungti'); ?></button>
                </form>
               
                <?php $__currentLoopData = $recipe->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="my-2 p-2 bg-light">
                        
                    </div>
                    <div class="card">
                        <div class="card-header text-white bg-dark">
                            <?php echo e($comment->user ? $comment->user->name : 'Naudotojas'); ?> 
                            (
                            <?php for($i = 0; $i < $comment->rating; $i++): ?>
                            <i class="fas fa-star text-warning"></i>
                            <?php endfor; ?>
                            )
                            <span class="float-right"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                        </div>
                        <div class="card-body">
                          <p class="card-text"><?php echo e($comment->comment); ?></p>
                        </div>
                      </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        </div>
        <div class="col-lg-4  p-2 shadow-sm">
            <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('planner.add', $recipe)); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <select class="custom-select" name="day" id="inputGroupSelect04" aria-label="Example select with button addon" required>
                        <option selected value="">Rinktis dieną...</option>
                        <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->day_number); ?>" <?php echo e($item->recipes()->where('recipe_id', $recipe->id)->exists() ? 'disabled' :''); ?>><?php echo e($item->day); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="submit">Pridėti į planuoklį</button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
            <div class="input-group">
                <select class="custom-select" name="day" id="inputGroupSelect04" aria-label="Example select with button addon" required>
                <option selected disabled value="">Turite prisijungti...</option>
                
                </select>
                <div class="input-group-append">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-secondary" type="submit">Pridėti į planuoklį</a>
                </div>
            </div>
            <?php endif; ?>

            <h3 class="mt-3 ">Ingridientai: 
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $recipe)): ?>
                <a href="<?php echo e(route('recipes.edit', $recipe)); ?>" class="float-right text-sm btn btn-sm btn-warning">Redaguoti</a>
                <?php endif; ?>
            </h3>
                <hr class="mx-4">
                    <?php if(count($recipe->ingredients) > 0): ?>
                        <div class="p-3">
                            <h5 class="lead">Produktai:</h5>
                            <ul>
                                <?php $__currentLoopData = $recipe->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if($recipe->time): ?>
                        <p class="mt-3 px-3">Paruošimo laikas: <span class="text-bold"><?php echo e($recipe->time); ?></span> min.</p>
                    <?php endif; ?>

                    <?php if($recipe->cook_time): ?>
                        <p class="mt-3 px-3">Kepimo(virimo) laikas: <span class="text-bold"><?php echo e($recipe->cook_time); ?></span> min.</p>
                    <?php endif; ?>

                    <?php if($recipe->calories): ?>
                        <p class="mt-3 px-3">Viso kalorijų: <span class="text-bold"><?php echo e($recipe->calories); ?></span> kcal.</p>
                    <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <script src="<?php echo e(asset('js/jquery.raty.js')); ?>"></script>
    <script>
        $('#hint').raty({
            'path': '/images/',
            'target':       '#rating',
            'targetType':   'score',
            'targetKeep':   true
        });
    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\receptaitest\resources\views/recipes/show.blade.php ENDPATH**/ ?>
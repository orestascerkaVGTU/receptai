<div class="accordion" id="accordionExample">
    <div class="card">
      <div class="card-header" id="headingOne">
        <h2 class="mb-0">
          <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Produktai (pasirinkti): <span class="text-danger">*</span>
          </button>
          
        </h2>
        <input wire:model="filterSearch" class="form-control form-control-sm" type="search" placeholder="Įvesti fragmentą ..">
      </div>
      
      <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
        <div class="card-body row ml-3">
            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check col-6 col-md-3 col-lg-2">
                <input class="form-check-input  <?php echo e($selectedIngredients ? '' : 'is-invalid'); ?>" type="checkbox" name="ingredients[]" wire:model="selectedIngredients" value="<?php echo e($item->id); ?>" id="ingredient<?php echo e($item->id); ?>">
                <label class="form-check-label" for="ingredients">
                  <?php echo e($item->name); ?>

                </label>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
           
        </div>
      </div>
    </div>
    
    
  </div>
<?php /**PATH C:\laragon\www\receptaitest\resources\views/livewire/recipes/form.blade.php ENDPATH**/ ?>
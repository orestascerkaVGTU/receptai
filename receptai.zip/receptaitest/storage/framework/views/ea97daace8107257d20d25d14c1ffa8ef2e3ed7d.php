

<?php $__env->startSection('title', 'Sukurti'); ?>

<?php $__env->startSection('content_header'); ?>
<h2>Sukurti naują receptą:</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="container py-3">

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        Ištaisykite žemiau esančias klaidas
    </div>
<?php endif; ?>


  <form action="<?php echo e(route('recipes.store')); ?>" method="POST" enctype="multipart/form-data" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="name">Pavadinimas <span class="text-danger">*</span></label>
        <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="...">
        <div id="nameFeedback" class="invalid-feedback">
          <?php echo e($errors->first('name')); ?>

        </div>
      </div>
        <div class="form-group">
          <label for="description">Aprašymas</label>
          <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="description" name="description" rows="3"><?php echo e(old('description')); ?></textarea>
          <div id="descriptionFeedback" class="invalid-feedback">
            <?php echo e($errors->first('description')); ?>

          </div>
        </div>

        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="time">Paruošimo laikas (min.):</label>
          </div>
          <select class="custom-select" id="time" name="time">
            <option selected  disabled>Pasirinkti ...</option>
            <?php for($i = 5; $i < 180; $i+=5): ?>
              <option value="<?php echo e($i); ?>" <?php echo e(old('time') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="cook_time">Kepimo laikas (min.):</label>
          </div>
          <select class="custom-select" id="cook_time" name="cook_time">
            <option selected disabled>Pasirinkti ...</option>
            <?php for($i = 5; $i < 180; $i+=5): ?>
              <option value="<?php echo e($i); ?>" <?php echo e(old('cook_time') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="calories">Kalorijos (kcal.):</label>
          </div>
          <select class="custom-select" id="calories" name="calories">
            <option selected disabled>Pasirinkti ...</option>
            <?php for($i = 5; $i < 2000; $i+=5): ?>
              <option value="<?php echo e($i); ?>" <?php echo e(old('calories') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="instructions">Instrukcijos: <span class="text-danger">*</span></label>
          <textarea class="form-control <?php echo e($errors->has('instructions') ? 'is-invalid' : ''); ?>" id="instructions" name="instructions" rows="3"><?php echo e(old('instructions')); ?></textarea>
          <div id="instructionsFeedback" class="invalid-feedback">
            <?php echo e($errors->first('instructions')); ?>

          </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('recipes.form')->html();
} elseif ($_instance->childHasBeenRendered('cLqXCWf')) {
    $componentId = $_instance->getRenderedChildComponentId('cLqXCWf');
    $componentTag = $_instance->getRenderedChildComponentTagName('cLqXCWf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cLqXCWf');
} else {
    $response = \Livewire\Livewire::mount('recipes.form');
    $html = $response->html();
    $_instance->logRenderedChild('cLqXCWf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <div class="custom-file my-3">
          <input type="file" class="custom-file-input <?php echo e($errors->has('file') ? 'is-invalid' : ''); ?>" name="file" id="file">
          <label class="custom-file-label" for="file">Pasirinkti nuotrauką</label>
          <div id="fileFeedback" class="invalid-feedback">
            <?php echo e($errors->first('file')); ?>

          </div>
        </div>

        <button type="submit" class="btn btn-success">Siųsti</button>
    </form>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
<script>

$('#description').summernote({
placeholder: 'Recepto aprašymas ..',
tabsize: 2,
height: 120,
toolbar: [
  ['style', ['style']],
  ['font', ['bold', 'underline', 'clear']],
  ['color', ['color']],
  ['para', ['ul', 'ol', 'paragraph']],
  ['table', ['table']],
  ['insert', ['link', 'picture', 'video']],
  ['view', ['fullscreen', 'codeview', 'help']]
]
});

$('#instructions').summernote({
placeholder: 'Recepto instrukcija 1,2,3 .. ',
tabsize: 2,
height: 120,
toolbar: [
  ['style', ['style']],
  ['font', ['bold', 'underline', 'clear']],
  ['color', ['color']],
  ['para', ['ul', 'ol', 'paragraph']],
  ['table', ['table']],
  ['insert', ['link', 'picture', 'video']],
  ['view', ['fullscreen', 'codeview', 'help']]
]
});
</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\receptaitest\resources\views/recipes/create.blade.php ENDPATH**/ ?>
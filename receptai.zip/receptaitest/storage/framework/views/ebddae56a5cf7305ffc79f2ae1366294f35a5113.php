

<?php $__env->startSection('title', 'Redaguoti'); ?>

<?php $__env->startSection('content_header'); ?>
<h2>Redaguoti receptą:</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-3">
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        Ištaisykite žemiau esančias klaidas
    </div>
<?php endif; ?>
<?php if(Session::has('message')): ?>
    <div class="alert alert-dismissible fade show <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <?php endif; ?>

  <form action="<?php echo e(route('recipes.update', $recipe)); ?>" method="POST" enctype="multipart/form-data" enctype="multipart/form-data">
      <?php echo method_field('PUT'); ?>
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="name">Pavadinimas <span class="text-danger">*</span></label>
        <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" value="<?php echo e($recipe->name); ?>">
        <div id="nameFeedback" class="invalid-feedback">
          <?php echo e($errors->first('name')); ?>

        </div>
      </div>
        <div class="form-group">
          <label for="description">Aprašymas</label>
          <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="description" name="description" rows="3"><?php echo e($recipe->description); ?></textarea>
          <div id="descriptionFeedback" class="invalid-feedback">
            <?php echo e($errors->first('description')); ?>

          </div>
        </div>

        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="time">Paruošimo laikas (min.):</label>
          </div>
          <select class="custom-select" id="time" name="time">
            
            <?php for($i = 5; $i < 180; $i+=5): ?>
              <option value="<?php echo e($i); ?>" <?php echo e($recipe->time == $i ? 'selected' :''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>


        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="cook_time">Kepimo laikas (min.):</label>
          </div>
          <select class="custom-select" id="cook_time" name="cook_time">
            <option selected disabled>Pasirinkti ...</option>
            <?php for($i = 5; $i < 180; $i+=5): ?>
            <option value="<?php echo e($i); ?>" <?php echo e($recipe->cook_time == $i ? 'selected' :''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="calories">Kalorijos (kcal.):</label>
          </div>
          <select class="custom-select" id="calories" name="calories">
            <option selected disabled>Pasirinkti ...</option>
            <?php for($i = 5; $i < 2000; $i+=5): ?>
            <option value="<?php echo e($i); ?>" <?php echo e($recipe->calories == $i ? 'selected' :''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="instructions">Instrukcijos: <span class="text-danger">*</span></label>
          <textarea class="form-control <?php echo e($errors->has('instructions') ? 'is-invalid' : ''); ?>" id="instructions" name="instructions" rows="3"><?php echo e($recipe->instructions); ?></textarea>
          <div id="instructionsFeedback" class="invalid-feedback">
            <?php echo e($errors->first('instructions')); ?>

          </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('recipes.form-edit', ['recipe' => $recipe])->html();
} elseif ($_instance->childHasBeenRendered('T9zEqKo')) {
    $componentId = $_instance->getRenderedChildComponentId('T9zEqKo');
    $componentTag = $_instance->getRenderedChildComponentTagName('T9zEqKo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T9zEqKo');
} else {
    $response = \Livewire\Livewire::mount('recipes.form-edit', ['recipe' => $recipe]);
    $html = $response->html();
    $_instance->logRenderedChild('T9zEqKo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
       

        <?php if($recipe->image): ?>
        <div class="my-3">
          <h5>Sena nuotrauka:</h5>
          <img style="width: 300px;" src="<?php echo e(\Storage::url($recipe->image)); ?>" alt="">
      </div>
        <?php endif; ?>
        <div class="custom-file my-3">
          <input type="file" class="custom-file-input <?php echo e($errors->has('file') ? 'is-invalid' : ''); ?>" name="file" id="file">
          <label class="custom-file-label" for="file">Pridėti naują nuotrauką</label>
          <div id="fileFeedback" class="invalid-feedback">
            <?php echo e($errors->first('file')); ?>

          </div>
        </div>

        <?php if(Auth::check() && Auth::user()->admin == true): ?>
        <div class="form-group">
          <label for="show">Ar receptas matomas?</label>
          <select class="form-control" id="show" name="show">
            <option <?php echo e($recipe->show ? 'selected' : ''); ?> value="1">Rodomas</option>
            <option <?php echo e(!$recipe->show ? 'selected' : ''); ?> value="0">Paslėptas</option>
          </select>
        </div>
        <?php endif; ?>
        

        <button type="submit" class="btn btn-success">Siųsti</button>
    </form>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

<script>
    
  $('#description').summernote({
    placeholder: 'Recepto aprašymas ..',
    tabsize: 2,
    height: 120,
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'underline', 'clear']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['table', ['table']],
      ['insert', ['link', 'picture', 'video']],
      ['view', ['fullscreen', 'codeview', 'help']]
    ]
  });

  $('#instructions').summernote({
    placeholder: 'Recepto instrukcija 1,2,3 .. ',
    tabsize: 2,
    height: 120,
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'underline', 'clear']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['table', ['table']],
      ['insert', ['link', 'picture', 'video']],
      ['view', ['fullscreen', 'codeview', 'help']]
    ]
  });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\receptaitest\resources\views/recipes/edit.blade.php ENDPATH**/ ?>